export module cursescontroller;
import controller;
import <map>;
import <vector>;

export class CursesController: public Controller {
    public:
    char getInput() override;
};
