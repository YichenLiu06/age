module pixel;

Pixel::Pixel(int x, int y, char fill): x{x}, y{y}, fill{fill} {}
