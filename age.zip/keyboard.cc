export module keyboard;
import controller;
import observer;
import event;
import <map>;
import <vector>;

export class Keyboard: public Controller {
    std::map<char, Event*> keybinds;
    std::vector<Observer *> observers;
    public:
    Keyboard();
    Event *getInput() override;
    void addBinding(char key, Event* event);
    void attach(Observer *observer) override;
    void detach(Observer *observer) override;
    void notifyObservers(Event *event) override;
};
