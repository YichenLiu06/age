module boxtexture;

BoxTexture::BoxTexture( double left, double right, double top, double bottom, char fill):
    top{top}, bottom{bottom}, left{left}, right{right}, fill{fill} {} 
    