export module gameobjectcomponent:component;
export class GameObject;

export class Component{
    public:
    GameObject* gameObject;
    virtual void update() = 0;
};
