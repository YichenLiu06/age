export module gameobjectcomponent:gameobject;
import <vector>;
import <memory>;
import <algorithm>;

export class Component;

export class GameObject {
    std::vector<std::unique_ptr<Component>> components;
    public:
    std::vector<double> position;
    GameObject(double x, double y, double z);
    void addComponent(Component *component);
    void removeComponent(Component *component);
    template <typename T> T* getComponent() const;
    void update();
};
