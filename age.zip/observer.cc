export module observer;
import event;

export class Observer {
    public:
    virtual void notify(Event* event) = 0;
    virtual ~Observer() = default;
};
