export module spritecomponent;
import gameobjectcomponent;
import observer;
import event;
import <variant>;

export class SpriteComponent: public Component, public Observer {
    public:
    bool visible = true;
    std::variant<char> sprite;
    SpriteComponent(char c);
    void setVisible(bool visible);
    //TODO: Move responding to events to behaviours later
    void notify(Event* event) override;
    void update() override;
};
