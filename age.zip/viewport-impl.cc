module;
#include <ncurses.h>

module viewport;
import view;
import spritecomponent;
import gameobjectcomponent;
import <vector>;
import <string>;
import <variant>;
import <cmath>;

ViewPort::ViewPort(int height, int width): height{height}, width{width}, image(std::vector<std::vector<char>>(height, std::vector<char>(width, ' '))) {
    setlocale(LC_ALL, "");
    initscr();
    noecho();
    cbreak(); 
    keypad(stdscr, TRUE);
    curs_set(0);
    nodelay(stdscr, TRUE);  

    for (int i = 0; i < width + 2; ++i){
        mvwaddch(stdscr, 0, i, ACS_HLINE);
        mvwaddch(stdscr, height+1, i, ACS_HLINE);
    }
    for (int i = 0; i < height + 2; ++i){
        mvwaddch(stdscr, i, 0, ACS_VLINE);
        mvwaddch(stdscr, i, width+1, ACS_VLINE);
    }

    mvwaddch(stdscr, 0, 0, ACS_ULCORNER);
    mvwaddch(stdscr, 0, width+1, ACS_URCORNER);
    mvwaddch(stdscr, height+1, 0, ACS_LLCORNER);
    mvwaddch(stdscr, height+1, width+1, ACS_LRCORNER);

    for (int i = 0; i < height; ++i ){
        for( int j = 0; j < width; ++j ){
            mvwaddch(stdscr, i+1, j+1, ' ');
        }
    }
}

void ViewPort::render(SpriteComponent* sprite) {
    if(sprite->visible){
        if(std::holds_alternative<char>(sprite->sprite)){
            image[std::round(sprite->gameObject->position[0])][std::round(sprite->gameObject->position[1])] = std::get<char>(sprite->sprite);
        }
    }
}

void ViewPort::render(std::string msg) {

}

void ViewPort::display() {
    for (int i = 0; i < height; ++i ){
        for( int j = 0; j < width; ++j ){
        mvwaddch(stdscr, i+1, j+1, image[i][j]);
        }
    }
    //TODO: Remove later
    int row = height + 3;
    mvwprintw(stdscr, row, 1, "Press spacebar to toggle visibility");
    refresh();
}

void ViewPort::clear() {
    image = std::vector<std::vector<char>>(height, std::vector<char>(width, ' '));
}
