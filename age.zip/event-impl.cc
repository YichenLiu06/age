module event;
import <string>;

Event::Event(std::string id): id{id} {}

std::string &Event::getId(){return id;}
