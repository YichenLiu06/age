module;
#include <ncurses.h>
#include <clocale>

module keyboard;
import controller;
import event;
import observer;
import <map>;
import <utility>;
import <algorithm>;

Keyboard::Keyboard(){
    keybinds[ERR] = nullptr;
}

Event *Keyboard::getInput(){
    char ch = getch();
    Event* input;
    if(keybinds.contains(ch))
        input = keybinds[ch];
    else
        input = nullptr;
    notifyObservers(input);
    return input;
}

void Keyboard::addBinding(char key, Event* event){
    if(key != ERR)
        keybinds.insert(std::pair<char, Event*>(key, event));
}

void Keyboard::attach(Observer *observer) {
    observers.push_back(observer);
}
void Keyboard::detach(Observer *observer) {
    observers.erase(std::find(observers.begin(), observers.end(), observer));
}
void Keyboard::notifyObservers(Event *event) {
    for(auto observer : observers){
        observer->notify(event);
    }
}
