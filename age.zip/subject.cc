export module subject;
import observer;
import event;
import <vector>;
import <algorithm>;

export class Subject {
    public:
    virtual void attach(Observer *observer) = 0;
    virtual void detach(Observer *observer) = 0;
    virtual void notifyObservers(Event *event) = 0;
    virtual ~Subject() = default;
};
