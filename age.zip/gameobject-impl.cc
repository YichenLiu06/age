module gameobjectcomponent:gameobject;
import gameobjectcomponent;
import <vector>;
import <memory>;
import <algorithm>;

GameObject::GameObject(double x, double y, double z): position{x, y, z} {}

void GameObject::addComponent(Component *component){
    components.push_back(std::unique_ptr<Component>(component));
    component->gameObject = this;
}

void GameObject::removeComponent(Component *component){
    components.erase(std::find_if(components.begin(), components.end(), [component](const std::unique_ptr<Component> &other){return component == other.get();}));
}

template <typename T> T* GameObject::getComponent() const {
    auto it =  std::find_if(components.begin(), components.end(), 
        [](Component* component){return dynamic_cast<T*>(component) != nullptr;});
    if(it != components.end()) return dynamic_cast<T*>(*it);
    else return nullptr;
}

void GameObject::update(){
    for(const auto &component :  components){
        component->update();
    }
}
