export module event;
import <string>;

export class Event {
    std::string id;
    public:
    std::string &getId();
    Event(std::string id);
};
