export module viewport;
import view;
import spritecomponent;
import gameobjectcomponent;
import <vector>;
import <string>;

export class ViewPort: public View {
    int height, width;
    std::vector<std::vector<char>> image;
    public:
    ViewPort(int height, int width);
    virtual void render(SpriteComponent* sprite) override;
    virtual void render(std::string msg) override;
    virtual void display() override;
    virtual void clear() override;
};
