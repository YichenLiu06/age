module;
#include <ncurses.h>

module spritecomponent;
import gameobjectcomponent;
import observer;
import event;
import <variant>;

SpriteComponent::SpriteComponent(char c): sprite{c} {
}

void SpriteComponent::setVisible(bool visible){
    this->visible = visible;
}

//TODO: Move responding to events to behaviours later
void SpriteComponent::notify(Event* event) {
    if(event != nullptr) setVisible(!visible);   
}

void SpriteComponent::update() {}
